var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_0arv.vj._.js")
R.c("server/chunks/0e5v_next_dist_esm_build_templates_app-route_0i0daqe.js")
R.c("server/chunks/0e5v_next_09tn071._.js")
R.c("server/chunks/[root-of-the-server]__0-i_~j.._.js")
R.c("server/chunks/0eb__1-main-main-new-main__next-internal_server_app_favicon_ico_route_actions_0vuuyze.js")
R.m(60750)
module.exports=R.m(60750).exports
