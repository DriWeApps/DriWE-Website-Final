var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/logout/route.js")
R.c("server/chunks/[externals]_next_dist_11bl3x3._.js")
R.c("server/chunks/[root-of-the-server]__0-i_~j.._.js")
R.c("server/chunks/0e5v_0pe9609._.js")
R.c("server/chunks/0h7z__next-internal_server_app_api_auth_logout_route_actions_0tc~rs1.js")
R.m(29458)
module.exports=R.m(29458).exports
