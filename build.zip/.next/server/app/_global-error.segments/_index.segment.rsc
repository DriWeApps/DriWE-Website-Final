1:"$Sreact.fragment"
2:I[68084,["/_next/static/chunks/0snsvbwy6an8m.js","/_next/static/chunks/11i.82lmiy0st.js"],"default"]
3:I[99906,["/_next/static/chunks/0snsvbwy6an8m.js","/_next/static/chunks/11i.82lmiy0st.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"7-P7aW-Y5cXKAtpK9S16E"}
