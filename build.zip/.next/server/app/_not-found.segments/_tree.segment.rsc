:HL["/_next/static/chunks/08sp6td81mlnz.css","style"]
:HL["/_next/static/chunks/0tjul~ztb7pc..css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"7-P7aW-Y5cXKAtpK9S16E"}
