globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/7-P7aW-Y5cXKAtpK9S16E/_buildManifest.js",
    "static/7-P7aW-Y5cXKAtpK9S16E/_ssgManifest.js",
    "static/7-P7aW-Y5cXKAtpK9S16E/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/103nglp-ao0o9.js",
    "static/chunks/0tcbmixl-lk6~.js",
    "static/chunks/1658x92xqw87x.js",
    "static/chunks/10x5pgphu2nya.js",
    "static/chunks/turbopack-07tv7l6a2g91m.js"
  ]
};
