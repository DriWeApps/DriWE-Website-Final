module.exports=[22091,(e,o,d)=>{}];

//# sourceMappingURL=0eb__1-main-main-new-main__next-internal_server_app_favicon_ico_route_actions_0vuuyze.js.map