module.exports=[63808,(e,o,d)=>{}];

//# sourceMappingURL=0h7z__next-internal_server_app_api_application_route_actions_0bzqbhc.js.map