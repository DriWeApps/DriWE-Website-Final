module.exports=[59296,(a,b,c)=>{}];

//# sourceMappingURL=0h7z__next-internal_server_app__global-error_page_actions_0i3gpu-.js.map