module.exports=[7332,(a,b,c)=>{}];

//# sourceMappingURL=0-~k_ebsite-1-main-main-new-main__next-internal_server_app_terms_page_actions_0fmkjn..js.map