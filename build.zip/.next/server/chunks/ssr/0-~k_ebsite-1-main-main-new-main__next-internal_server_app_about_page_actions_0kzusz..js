module.exports=[24198,(a,b,c)=>{}];

//# sourceMappingURL=0-~k_ebsite-1-main-main-new-main__next-internal_server_app_about_page_actions_0kzusz..js.map