module.exports=[16400,(a,b,c)=>{}];

//# sourceMappingURL=0s-x_site-1-main-main-new-main__next-internal_server_app_contact_page_actions_0i.jn90.js.map