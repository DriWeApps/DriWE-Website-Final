module.exports=[84832,(a,b,c)=>{}];

//# sourceMappingURL=13ja_e-1-main-main-new-main__next-internal_server_app__not-found_page_actions_0ef6eod.js.map