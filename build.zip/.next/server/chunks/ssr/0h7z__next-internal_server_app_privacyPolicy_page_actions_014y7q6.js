module.exports=[2842,(a,b,c)=>{}];

//# sourceMappingURL=0h7z__next-internal_server_app_privacyPolicy_page_actions_014y7q6.js.map