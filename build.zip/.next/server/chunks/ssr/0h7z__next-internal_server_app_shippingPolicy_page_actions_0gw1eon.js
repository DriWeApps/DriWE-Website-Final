module.exports=[67877,(a,b,c)=>{}];

//# sourceMappingURL=0h7z__next-internal_server_app_shippingPolicy_page_actions_0gw1eon.js.map