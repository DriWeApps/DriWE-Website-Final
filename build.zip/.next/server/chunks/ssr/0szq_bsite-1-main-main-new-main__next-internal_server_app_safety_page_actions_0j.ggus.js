module.exports=[79441,(a,b,c)=>{}];

//# sourceMappingURL=0szq_bsite-1-main-main-new-main__next-internal_server_app_safety_page_actions_0j.ggus.js.map