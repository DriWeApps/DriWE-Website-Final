module.exports=[23818,(a,b,c)=>{}];

//# sourceMappingURL=0.0z_te-1-main-main-new-main__next-internal_server_app_dashboard_page_actions_0cu~kim.js.map