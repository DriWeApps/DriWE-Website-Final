module.exports=[85032,(a,b,c)=>{}];

//# sourceMappingURL=13ja_e-1-main-main-new-main__next-internal_server_app_why-choose_page_actions_08_ga1h.js.map