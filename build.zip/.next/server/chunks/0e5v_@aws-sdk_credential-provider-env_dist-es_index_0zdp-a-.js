module.exports=[65612,r=>{"use strict";r.s([],90588),r.i(90588);var s=r.i(95722);r.s(["fromEnv",()=>s.fromEnv],65612)}];

//# sourceMappingURL=0e5v_%40aws-sdk_credential-provider-env_dist-es_index_0zdp-a-.js.map